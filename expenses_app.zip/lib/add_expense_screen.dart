import 'package:flutter/material.dart';
import 'model/expense_model.dart';

class AddExpenseScreen extends StatefulWidget {
  const AddExpenseScreen(this.addExpenseToList, {super.key});

  final void Function(ExpenseModel) addExpenseToList;
  @override
  State<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {
  DateTime? selectedDate;
  Categories selectedCategory = Categories.leisure;
  final titleController = TextEditingController();
  final amountController = TextEditingController();

  @override
  void dispose() {
    titleController.dispose();
    amountController.dispose();
    super.dispose();
  }

  void submitData() {
    final enteredAmount = double.tryParse(amountController.text);
    final amountIsInvalid = (enteredAmount == null) || (enteredAmount <= 0);
    if (titleController.text.isEmpty || amountIsInvalid || selectedDate == null) {
      showDialog(
          context: context,
          builder: (ctx) => const AlertDialog(
                title: Text('Invalid Input'),
                content: Text('Please make sure a valid title, amount,date, and category was entered'),
              ));
      return;
    }
    widget.addExpenseToList(ExpenseModel(title: titleController.text, amount: enteredAmount, date: selectedDate!, category: selectedCategory));
  }

  void showDate() async {
    final pickedDate = await showDatePicker(
        context: context, firstDate: DateTime.now().subtract(const Duration(days: 365)), lastDate: DateTime.now(), initialDate: DateTime.now());

    setState(() {
      selectedDate = pickedDate;
    });
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return SizedBox(
      height: width < 600 ? MediaQuery.of(context).size.height / 2 : MediaQuery.of(context).size.height,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(
                label: Text('Title'),
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: amountController,
                    decoration: const InputDecoration(label: Text('Amount')),
                  ),
                ),
                const SizedBox(width: 70),
                Text(selectedDate == null ? 'No date selected' : formatter.format(selectedDate!)),
                IconButton(
                  onPressed: showDate,
                  icon: const Icon(Icons.calendar_month),
                )
              ],
            ),
            const SizedBox(height: 15),
            Row(
              children: [
                DropdownButton(
                  value: selectedCategory,
                  items: Categories.values
                      .map((category) => DropdownMenuItem(
                            value: category,
                            child: Text(
                              category.name,
                            ),
                          ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedCategory = value!;
                    });
                  },
                ),
                const Spacer(),
                TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('Cancel')),
                const SizedBox(width: 10),
                ElevatedButton(onPressed: submitData, child: const Text('Save Expenses'))
              ],
            )
          ],
        ),
      ),
    );
  }
}
