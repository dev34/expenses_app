import 'package:expenses_app/add_expense_screen.dart';
import 'package:expenses_app/expense_screen.dart';
import 'package:expenses_app/model/expense_model.dart';
import 'package:flutter/material.dart';

var kDarkColorScheme = ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 5, 99, 125), brightness: Brightness.dark);

void main() {
  runApp(
    MaterialApp(
      // themeMode: ThemeMode.dark,
      darkTheme: ThemeData.dark().copyWith(
        useMaterial3: true,
        colorScheme: kDarkColorScheme,
        cardTheme: const CardTheme().copyWith(
          color: kDarkColorScheme.secondaryContainer,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(foregroundColor: kDarkColorScheme.onPrimaryContainer, backgroundColor: kDarkColorScheme.primaryContainer),
        ),
      ),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
      ),
      home: const ExpensesApp(),
    ),
  );
}

class ExpensesApp extends StatefulWidget {
  const ExpensesApp({super.key});

  @override
  State<ExpensesApp> createState() => _ExpensesAppState();
}

class _ExpensesAppState extends State<ExpensesApp> {
  final List<ExpenseModel> expenses = [ExpenseModel(title: 'PS5', amount: 499, date: DateTime.now(), category: Categories.leisure)];

  // void expenseSerializer(List<ExpenseModel> expense) {
  //   print(jsonEncode(expense));
  // }

  // void saveExpensesToDevices() {
  //   preferences!.setString('expenses', jsonEncode(expenses));
  // }

  // List<ExpenseModel> getExpensesFromDevices() {
  //   var expensesList = preferences!.getString('expenses');
  //   return jsonDecode(expensesList);
  // }

  void addExpenseToList(ExpenseModel expense) {
    setState(() {
      expenses.add(expense);
    });
  }

  void removeExpenseFromList(int index, ExpenseModel expense) {
    setState(() {
      expenses.removeAt(index);
    });
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 3),
        content: const Text(
          'Expense has been removed',
        ),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () => setState(
            () {
              expenses.insert(index, expense);
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text('Flutter ExpenseTracker'),
        actions: [
          IconButton(
            onPressed: () {
              showModalBottomSheet(
                useSafeArea: true,
                isScrollControlled: true,
                context: context,
                builder: (ctx) {
                  return AddExpenseScreen(addExpenseToList);
                },
              );
            },
            icon: const Icon(Icons.add),
          )
        ],
      ),
      body: expenses.isEmpty
          ? const Center(
              child: Text('No expenses have been added'),
            )
          : ExpenseListScreen(expenses: expenses, removeExpenseFromList),
    );
  }
}

// class ExpensesApp extends StatefulWidget {
//   const ExpensesApp({super.key});

//   @override
//   State<ExpensesApp> createState() => _ExpensesAppState();
// }

// class _ExpensesAppState extends State<ExpensesApp> {
  
