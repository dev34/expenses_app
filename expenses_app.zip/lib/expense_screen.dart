import 'package:expenses_app/model/expense_model.dart';
import 'package:expenses_app/widgets/chart/chart.dart';
import 'package:expenses_app/widgets/expenses/expenses_list.dart';
import 'package:flutter/material.dart';

class ExpenseListScreen extends StatelessWidget {
  const ExpenseListScreen(this.removeExpenseFromList, {required this.expenses, super.key});

  final List<ExpenseModel> expenses;

  final void Function(int, ExpenseModel) removeExpenseFromList;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return width < 600
        ? Column(
            children: [
              Chart(expenses: expenses),
              const SizedBox(height: 20),
              ExpensesList(
                expenses: expenses,
                removeExpenseFromList,
              ),
            ],
          )
        : Row(
            children: [
              Expanded(child: Chart(expenses: expenses)),
              // const SizedBox(height: 20),
              ExpensesList(expenses: expenses, removeExpenseFromList),
            ],
          );
  }
}
