import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

final formatter = DateFormat.yMd();

enum Categories { leisure, work, food, travel }

const Map categoryIcons = {
  'leisure': Icons.movie,
  'work': Icons.work,
  'food': Icons.lunch_dining,
  'travel': Icons.flight_takeoff,
};

class ExpenseModel {
  ExpenseModel({required this.title, required this.amount, required this.date, required this.category});
  final String title;
  final double amount;
  final DateTime date;
  final Categories category;

  String get formattedDate => formatter.format(date);
}

// class ExpenseBuckets {

// }
