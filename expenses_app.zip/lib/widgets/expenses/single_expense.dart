import 'package:expenses_app/model/expense_model.dart';
import 'package:flutter/material.dart';

class SingleExpense extends StatelessWidget {
  const SingleExpense({required this.expenseData, super.key});

  final ExpenseModel expenseData;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              expenseData.title,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 3),
            Row(
              children: [
                Text('\$${expenseData.amount}'),
                const Spacer(),
                Icon(categoryIcons[expenseData.category.name]),
                const SizedBox(width: 10),
                Text(expenseData.formattedDate)
              ],
            )
          ],
        ),
      ),
    );
  }
}
