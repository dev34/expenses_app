import 'package:expenses_app/model/expense_model.dart';
import 'package:expenses_app/widgets/expenses/single_expense.dart';
import 'package:flutter/material.dart';

class ExpensesList extends StatelessWidget {
  const ExpensesList(this.removeExpenseFromList, {super.key, required this.expenses});
  final List<ExpenseModel> expenses;
  final void Function(int, ExpenseModel) removeExpenseFromList;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: ListView.builder(
          itemCount: expenses.length,
          itemBuilder: (ctx, index) => Dismissible(
            direction: DismissDirection.endToStart,
            onDismissed: (direction) {
              removeExpenseFromList(index, expenses[index]);
            },
            background: Container(
              margin: const EdgeInsets.symmetric(vertical: 3),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(5), color: const Color.fromARGB(183, 236, 25, 9)),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Icon(
                    Icons.delete,
                    color: Colors.white,
                  ),
                  SizedBox(
                    width: 30,
                  )
                ],
              ),
            ),
            key: ValueKey(
              expenses[index],
            ),
            child: SingleExpense(
              expenseData: expenses[index],
            ),
          ),
        ),
      ),
    );
  }
}
