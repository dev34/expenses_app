import 'package:expenses_app/model/expense_model.dart';
import 'package:expenses_app/widgets/chart/chart_bar.dart';
import 'package:flutter/material.dart';

class Chart extends StatelessWidget {
  const Chart({super.key, required this.expenses});

  final List<ExpenseModel> expenses;

  double addTotalExpenses() {
    double totalAmount = 0;
    for (final expense in expenses) {
      totalAmount += expense.amount;
    }
    return totalAmount;
  }

  double addCategoryExpenses(Categories filterCategory) {
    double totalAmount = 0;
    final List<ExpenseModel> filteredExpenses = expenses.where((expense) => expense.category == filterCategory).toList();
    for (final expense in filteredExpenses) {
      totalAmount += expense.amount;
    }
    return totalAmount;
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isDarkMode = MediaQuery.of(context).platformBrightness == Brightness.dark;
    double totalExpenses = addTotalExpenses();
    return Material(
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 30, 10, 20),
        color: isDarkMode ? Theme.of(context).colorScheme.secondaryContainer : null,
        height: width < 600 ? 250 : double.infinity,
        child: Row(
          children: [
            for (final category in Categories.values)
              Expanded(
                child: Column(
                  // mainAxisSize: MainAxisSize.min,
                  children: [
                    ChartBar(fill: addCategoryExpenses(category) / totalExpenses),
                    const SizedBox(height: 20),
                    Icon(categoryIcons[category.name]),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
